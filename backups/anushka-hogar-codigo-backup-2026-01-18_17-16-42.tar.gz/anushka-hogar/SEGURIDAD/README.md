# SEGURIDAD - ARCHIVOS CRÍTICOS

Este directorio contiene backups cifrados de claves y configuraciones críticas.

**NO SUBIR A GITHUB**

Contenido:
- encryption_key_backup.txt.gpg - Backup cifrado de la clave de cifrado AES-256

