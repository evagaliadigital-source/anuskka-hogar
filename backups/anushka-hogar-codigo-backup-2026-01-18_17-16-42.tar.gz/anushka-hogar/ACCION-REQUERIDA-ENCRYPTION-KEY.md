# ⚠️ ACCIÓN REQUERIDA: CONFIGURAR ENCRYPTION_KEY

## EVA: DEBES HACER ESTO AHORA

Tu aplicación usa cifrado AES-256 para proteger datos sensibles (teléfonos, emails, direcciones).

**Actualmente NO tienes configurada la clave de cifrado.**

---

## PASO 1: GENERAR LA CLAVE (AHORA)

Ejecuta este comando en tu terminal:

```bash
cd /home/user/anushka-hogar
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

**Te devolverá algo como:**
```
a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6abcd==
```

**COPIA ese valor** (es tu clave única).

---

## PASO 2: CONFIGURAR EN LOCAL (.dev.vars)

```bash
cd /home/user/anushka-hogar
echo "ENCRYPTION_KEY=TU_CLAVE_GENERADA_AQUI" > .dev.vars

# Ejemplo:
# echo "ENCRYPTION_KEY=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6abcd==" > .dev.vars
```

**Verifica:**
```bash
cat .dev.vars
```

---

## PASO 3: CONFIGURAR EN PRODUCCIÓN (Cloudflare Pages)

```bash
cd /home/user/anushka-hogar
npx wrangler pages secret put ENCRYPTION_KEY --project-name anushka-hogar
```

Te pedirá el valor → **Pega la misma clave del paso 1**

---

## PASO 4: CREAR BACKUP CIFRADO DE LA CLAVE

Sigue la guía en: `BACKUP-CLAVE-CIFRADO.md`

Resumen:
1. Crear archivo con la clave
2. Cifrarlo con GPG
3. Guardar en AI Drive, USB, Google Drive
4. Guardar contraseña GPG en gestor de contraseñas

---

## ¿POR QUÉ ES IMPORTANTE?

Sin `ENCRYPTION_KEY`:
- ❌ No puedes cifrar datos nuevos
- ❌ No puedes descifrar datos existentes
- ❌ La aplicación dará errores en producción

Con `ENCRYPTION_KEY`:
- ✅ Datos de clientes protegidos
- ✅ Cumplimiento RGPD
- ✅ Aplicación funciona correctamente

---

## TIEMPO ESTIMADO

- Generar clave: 30 segundos
- Configurar local: 1 minuto
- Configurar producción: 2 minutos
- Crear backup cifrado: 10 minutos

**TOTAL: 15 minutos**

---

## ¿DUDAS?

Lee el archivo completo: `BACKUP-CLAVE-CIFRADO.md`
