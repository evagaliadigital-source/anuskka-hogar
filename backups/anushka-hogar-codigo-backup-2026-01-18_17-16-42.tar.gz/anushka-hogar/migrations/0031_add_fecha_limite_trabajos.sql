-- Migration: Agregar fecha_limite a trabajos
-- Description: Campo para recordatorio diario a las 9:00 AM

-- Agregar columna fecha_limite
ALTER TABLE trabajos ADD COLUMN fecha_limite DATE;

-- Crear índice para búsquedas rápidas
CREATE INDEX IF NOT EXISTS idx_trabajos_fecha_limite ON trabajos(fecha_limite);
