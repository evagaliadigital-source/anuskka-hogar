# 🔑 PROCEDIMIENTO DE BACKUP DE CLAVE DE CIFRADO

## IMPORTANTE: LEE ESTO PRIMERO

Tu clave de cifrado (`ENCRYPTION_KEY`) es **CRÍTICA**. Sin ella, no puedes descifrar los datos de clientes (teléfonos, emails, direcciones).

**Si pierdes esta clave = Pierdes TODOS los datos cifrados para siempre.**

---

## PASO 1: OBTENER LA CLAVE ACTUAL

### Opción A: Desde Cloudflare Pages Dashboard

1. Ve a: https://dash.cloudflare.com
2. Navega a: Workers & Pages > anushka-hogar > Settings > Environment Variables
3. Busca: `ENCRYPTION_KEY`
4. Haz clic en "Decrypt" para ver el valor
5. **Cópialo** (ejemplo: `a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6`)

### Opción B: Desde tu .dev.vars local

```bash
cd /home/user/anushka-hogar
cat .dev.vars | grep ENCRYPTION_KEY
```

**Anota el valor en papel temporalmente.**

---

## PASO 2: CREAR ARCHIVO DE BACKUP CIFRADO

### 2.1 Instalar GPG (si no lo tienes)

```bash
# Verificar si ya está instalado
gpg --version

# Si no está instalado:
sudo apt-get update && sudo apt-get install -y gnupg
```

### 2.2 Crear archivo con la clave

```bash
# Ir al directorio de tu proyecto
cd /home/user/anushka-hogar

# Crear archivo temporal con la clave
echo "ENCRYPTION_KEY=TU_CLAVE_AQUI" > encryption_key_backup.txt

# Ejemplo:
# echo "ENCRYPTION_KEY=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6" > encryption_key_backup.txt
```

### 2.3 Cifrar el archivo con GPG

```bash
# Cifrar con contraseña
gpg -c encryption_key_backup.txt

# Te pedirá una contraseña → USA UNA FUERTE (mínimo 20 caracteres)
# Ejemplo de contraseña fuerte: "Galia2025!EncryptionKey@SecureBackup#Eva"

# Resultado: encryption_key_backup.txt.gpg (archivo cifrado)
```

### 2.4 Borrar el archivo original (sin cifrar)

```bash
# Borrar de forma segura (sobrescribe con datos aleatorios)
shred -u -n 3 encryption_key_backup.txt

# Verificar que se eliminó
ls -la | grep encryption_key
# Solo debe aparecer: encryption_key_backup.txt.gpg
```

---

## PASO 3: GUARDAR EL ARCHIVO CIFRADO EN 3 UBICACIONES

### 3.1 AI Drive (respaldo remoto)

```bash
# Crear carpeta CRITICO si no existe
mkdir -p /mnt/aidrive/CRITICO

# Copiar archivo cifrado
cp encryption_key_backup.txt.gpg /mnt/aidrive/CRITICO/

# Verificar
ls -lh /mnt/aidrive/CRITICO/
```

### 3.2 Directorio local del proyecto

```bash
# Crear carpeta segura
mkdir -p /home/user/anushka-hogar/SEGURIDAD

# Copiar archivo cifrado
cp encryption_key_backup.txt.gpg /home/user/anushka-hogar/SEGURIDAD/

# Añadir al .gitignore para NO subirlo a GitHub
echo "SEGURIDAD/" >> /home/user/anushka-hogar/.gitignore
echo "*.gpg" >> /home/user/anushka-hogar/.gitignore

# Verificar
cat /home/user/anushka-hogar/.gitignore | grep -E "SEGURIDAD|gpg"
```

### 3.3 USB físico o almacenamiento externo (RECOMENDADO)

**Tú debes hacer esto manualmente:**

1. Descarga el archivo cifrado: `encryption_key_backup.txt.gpg`
2. Guárdalo en:
   - USB físico (en caja fuerte o lugar seguro)
   - Google Drive personal (carpeta privada "CRITICO - Galia Digital")
   - Nube personal (Dropbox, OneDrive, etc.)

---

## PASO 4: GUARDAR LA CONTRASEÑA DE GPG

**La contraseña para descifrar el archivo es TAN IMPORTANTE como la clave misma.**

### Opciones para guardar la contraseña:

#### Opción A: Gestor de contraseñas (RECOMENDADO)

- **1Password**
- **Bitwarden**
- **LastPass**
- **Dashlane**

Crea una entrada:
- **Título:** "Galia Digital - Clave de Cifrado Backup"
- **Usuario:** eva@galiadigital.com
- **Contraseña:** [Tu contraseña GPG de 20+ caracteres]
- **Notas:** "Contraseña para descifrar encryption_key_backup.txt.gpg"

#### Opción B: Papel en caja fuerte

Escribe en papel:
```
GALIA DIGITAL - BACKUP CLAVE CIFRADO
Contraseña GPG: [tu contraseña aquí]
Archivo: encryption_key_backup.txt.gpg
Ubicaciones:
  - AI Drive: /mnt/aidrive/CRITICO/
  - USB: [ubicación física]
  - Google Drive: CRITICO - Galia Digital/

FECHA: 17 Enero 2026
```

Guarda el papel en:
- Caja fuerte personal
- Sobre cerrado en banco
- Con tu gestor/notario

---

## PASO 5: PROBAR LA RESTAURACIÓN

**CRÍTICO: Debes probar que puedes descifrar el backup AHORA.**

```bash
# Ir a la carpeta donde guardaste el backup
cd /mnt/aidrive/CRITICO

# Descifrar el archivo (te pedirá la contraseña)
gpg -d encryption_key_backup.txt.gpg

# Si sale correctamente, verás:
# ENCRYPTION_KEY=a1b2c3d4e5f6g7h8i9j0k1l2m3n4o5p6q7r8s9t0u1v2w3x4y5z6

# Si sale "gpg: decryption failed: Bad session key"
# → La contraseña es incorrecta, inténtalo de nuevo
```

✅ **Si ves la clave correctamente, el backup funciona.**

---

## PASO 6: LIMPIAR ARCHIVOS TEMPORALES

```bash
# Borrar el archivo cifrado del directorio actual
cd /home/user/anushka-hogar
shred -u -n 3 encryption_key_backup.txt.gpg

# Solo debe quedar en:
# - AI Drive: /mnt/aidrive/CRITICO/
# - Local seguro: /home/user/anushka-hogar/SEGURIDAD/
# - USB físico (que guardarás manualmente)
```

---

## RESUMEN DE UBICACIONES

| Ubicación | Archivo | Estado |
|-----------|---------|--------|
| **AI Drive** | `/mnt/aidrive/CRITICO/encryption_key_backup.txt.gpg` | ✅ Remoto |
| **Local** | `/home/user/anushka-hogar/SEGURIDAD/encryption_key_backup.txt.gpg` | ✅ Local |
| **USB físico** | `encryption_key_backup.txt.gpg` (tú lo copias) | ⚠️ Manual |
| **Google Drive** | `CRITICO - Galia Digital/encryption_key_backup.txt.gpg` | ⚠️ Manual |
| **Contraseña GPG** | Gestor de contraseñas o papel en caja fuerte | ⚠️ Manual |

---

## 🚨 ESCENARIO DE EMERGENCIA: CÓMO RECUPERAR LA CLAVE

### Si pierdes acceso a Cloudflare:

1. **Descargar el backup cifrado** desde:
   - AI Drive: `/mnt/aidrive/CRITICO/encryption_key_backup.txt.gpg`
   - USB físico
   - Google Drive

2. **Descifrar el archivo:**
   ```bash
   gpg -d encryption_key_backup.txt.gpg > encryption_key_recuperada.txt
   # Ingresar la contraseña (desde tu gestor de contraseñas)
   ```

3. **Ver la clave:**
   ```bash
   cat encryption_key_recuperada.txt
   # Copiar el valor de ENCRYPTION_KEY
   ```

4. **Configurar en nuevo proveedor:**
   ```bash
   # Si migras a Vercel:
   vercel env add ENCRYPTION_KEY
   # Pegar el valor de la clave

   # Si migras a Supabase:
   # Dashboard > Settings > Vault > Secrets > Add Secret
   # Name: ENCRYPTION_KEY
   # Value: [pegar la clave]
   ```

5. **Borrar archivo descifrado:**
   ```bash
   shred -u -n 3 encryption_key_recuperada.txt
   ```

---

## ✅ CHECKLIST FINAL

- [ ] Obtuve la clave de Cloudflare Pages Dashboard
- [ ] Creé archivo `encryption_key_backup.txt` con la clave
- [ ] Cifré con GPG usando contraseña fuerte (20+ caracteres)
- [ ] Guardé archivo cifrado en AI Drive
- [ ] Guardé archivo cifrado en carpeta local segura
- [ ] Guardé contraseña GPG en gestor de contraseñas
- [ ] Probé descifrar el archivo correctamente
- [ ] Copié archivo cifrado a USB físico (pendiente manual)
- [ ] Subí archivo cifrado a Google Drive personal (pendiente manual)
- [ ] Borré todos los archivos temporales sin cifrar

---

## 🔐 SEGURIDAD

**NUNCA:**
- ❌ Envíes la clave por email/WhatsApp
- ❌ Subas la clave sin cifrar a GitHub
- ❌ Compartas la contraseña GPG con nadie
- ❌ Guardes la clave en texto plano en tu ordenador

**SIEMPRE:**
- ✅ Usa cifrado GPG con contraseña fuerte
- ✅ Guarda backups en 3+ ubicaciones diferentes
- ✅ Prueba la restauración periódicamente (cada 6 meses)
- ✅ Actualiza el backup si cambias la clave

---

## 📞 CONTACTO DE EMERGENCIA

Si necesitas ayuda para recuperar la clave, contacta:
- Sergio (CTO) - [email/teléfono]
- Proveedor de hosting alternativo
- Consultor de seguridad

**TIEMPO ESTIMADO DE RECUPERACIÓN:**
- Con backup cifrado: **1 hora**
- Sin backup: **Imposible - pérdida total de datos cifrados**
