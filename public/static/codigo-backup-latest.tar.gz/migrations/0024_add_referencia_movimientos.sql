-- Añadir campo referencia a stock_movimientos
ALTER TABLE stock_movimientos ADD COLUMN referencia TEXT;
