# REGISTRO DE ACTIVIDADES DE TRATAMIENTO
## ANUSHKA HOGAR

**De conformidad con el artículo 30 del RGPD (Reglamento UE 2016/679)**

---

## DATOS DEL RESPONSABLE

**Responsable del tratamiento:**
- Nombre: Ana María Ramos Minaya
- DNI: 32771812D
- Nombre comercial: Anushka Hogar
- Dirección: Av de Monelos nº109, 15009 A Coruña
- Teléfono: 666 308 290
- Email: anuskkahogar@gmail.com
- Tipo de actividad: Autónoma - Confección e instalación de cortinas, estores y mosquiteras

---

## TRATAMIENTO 1: GESTIÓN DE CLIENTES

### 1.1 Identificación del Tratamiento

**Nombre del tratamiento:** Gestión de Clientes y Trabajos

**Responsable:** Ana María Ramos Minaya (Anushka Hogar)

**Delegado de Protección de Datos:** No aplica (empresa pequeña sin tratamiento masivo de datos sensibles)

### 1.2 Finalidades del Tratamiento

El tratamiento de datos personales tiene las siguientes finalidades:

1. **Gestión comercial:**
   - Gestión de presupuestos y ofertas
   - Gestión de pedidos y trabajos de cortinas, estores y mosquiteras
   - Seguimiento de proyectos de diseño y confección
   - Coordinación de citas e instalaciones

2. **Comunicación con clientes:**
   - Notificaciones sobre estado de trabajos
   - Confirmación de citas y entregas
   - Gestión de incidencias y reclamaciones
   - Comunicaciones informativas sobre servicios

3. **Facturación y contabilidad:**
   - Emisión de facturas
   - Gestión de cobros y pagos
   - Cumplimiento de obligaciones fiscales y contables

4. **Obligaciones legales:**
   - Conservación de facturas durante 5 años (Ley General Tributaria)
   - Cumplimiento de normativa mercantil y fiscal

### 1.3 Categorías de Interesados

- Clientes particulares (personas físicas)
- Clientes empresariales (representantes de empresas)
- Personas de contacto de clientes

### 1.4 Categorías de Datos Personales

**Datos identificativos:**
- Nombre y apellidos
- Número de cliente (pseudónimo: C-0001, C-0002, etc.)

**Datos de contacto:**
- Teléfono (cifrado AES-256-GCM)
- Email (cifrado AES-256-GCM)
- Dirección postal (cifrado AES-256-GCM, solo si contrata instalación)
- Ciudad y código postal

**Datos comerciales:**
- Trabajos realizados (tipo de cortina, estor, mosquitera)
- Presupuestos solicitados
- Facturas emitidas
- Notas y preferencias del cliente
- Historial de incidencias

**NO tratamos datos especialmente protegidos:**
- NO datos de salud
- NO datos de origen racial o étnico
- NO datos sobre religión o creencias
- NO datos sobre orientación sexual
- NO datos biométricos

### 1.5 Base Legal del Tratamiento

**Bases legales aplicables:**

1. **Consentimiento del interesado (Art. 6.1.a RGPD):**
   - Consentimiento explícito mediante checkbox obligatorio
   - Registrado en base de datos con IP, fecha y versión de política
   - Revocable en cualquier momento

2. **Ejecución de contrato (Art. 6.1.b RGPD):**
   - Necesario para prestar el servicio contratado
   - Gestión de presupuestos, trabajos e instalaciones

3. **Obligación legal (Art. 6.1.c RGPD):**
   - Conservación de facturas 5 años (Art. 30 Ley General Tributaria)
   - Obligaciones fiscales y mercantiles

### 1.6 Destinatarios de los Datos

**Cesión de datos:**

- **NO se ceden datos a terceros con fines comerciales**

**Comunicaciones obligatorias por ley:**
- Agencia Tributaria (facturas y datos fiscales)
- Entidades bancarias (para procesamiento de pagos)

**Encargados del tratamiento:**
- Cloudflare, Inc. (hosting y base de datos)
  - Función: Alojamiento web y gestión de base de datos D1
  - Ubicación: Unión Europea (datacenters en UE)
  - DPA firmado: https://www.cloudflare.com/cloudflare-customer-dpa/
  - Certificaciones: ISO 27001, SOC 2 Type II
  - Garantías: Cláusulas Contractuales Tipo aprobadas por la Comisión Europea

### 1.7 Transferencias Internacionales

**NO se realizan transferencias internacionales de datos fuera del Espacio Económico Europeo (EEE).**

**Nota:** Cloudflare almacena los datos en datacenters ubicados en la Unión Europea, cumpliendo con el RGPD.

### 1.8 Plazo de Conservación

**Criterios de conservación:**

1. **Clientes activos:**
   - Duración: Mientras exista relación comercial activa
   - Criterio: Cliente con trabajos en los últimos 12 meses

2. **Clientes inactivos:**
   - Duración: 5 años desde última factura
   - Base legal: Obligación legal fiscal (Ley General Tributaria Art. 30)
   - Acción: Marcado como `activo = 0` (no eliminación inmediata)

3. **Después de 5 años:**
   - Eliminación segura de la base de datos
   - O anonimización (eliminar datos personales, conservar solo estadísticas)

4. **Derecho de supresión anticipado:**
   - El cliente puede solicitar eliminación antes de 5 años
   - Se evalúa caso por caso (si hay obligación legal de conservar facturas)
   - Anonimización como alternativa cuando aplica obligación legal

### 1.9 Medidas de Seguridad Técnicas

**Nivel de seguridad aplicado:** ALTO

**Medidas técnicas implementadas:**

1. **Cifrado de datos:**
   - Cifrado en reposo: AES-256-GCM (estándar militar)
   - Cifrado en tránsito: HTTPS/TLS 1.3
   - Campos cifrados: teléfono, email, dirección
   - Clave de cifrado: Almacenada en variables de entorno seguras

2. **Control de acceso:**
   - Autenticación: JWT (JSON Web Tokens) con expiración 24 horas
   - Contraseñas: bcrypt con salt factor 10
   - Roles definidos: Admin, Tienda, Empleada, Cliente
   - Principio de mínimo privilegio

3. **Auditoría completa:**
   - Registro de TODAS las operaciones
   - Logs con: usuario, acción, tabla, registro, IP, timestamp
   - Conservación de logs: 30 días
   - Trazabilidad completa de accesos y cambios

4. **Copias de seguridad:**
   - Frecuencia: Automáticas diarias (3:00 AM)
   - Ubicación: Doble (AI Drive + local)
   - Cifrado: Backups cifrados
   - Retención: 30 días
   - Pruebas de restauración: Mensuales

5. **Infraestructura:**
   - Proveedor: Cloudflare (certificación ISO 27001)
   - Datacenters: Tier IV en Unión Europea
   - DDoS protection: Activa
   - WAF (Web Application Firewall): Activa

### 1.10 Medidas de Seguridad Organizativas

1. **Política de acceso:**
   - Solo personal autorizado tiene acceso
   - Credenciales individuales (no compartidas)
   - Revisión periódica de permisos

2. **Formación:**
   - Documentación completa del sistema
   - Procedimientos documentados
   - Guías de uso y seguridad

3. **Procedimientos:**
   - Gestión de incidencias de seguridad
   - Notificación de brechas (protocolo 72h)
   - Gestión de solicitudes RGPD (plazo 30 días)

4. **Revisión:**
   - Auditoría mensual de logs
   - Revisión anual de medidas de seguridad
   - Actualización de políticas según cambios normativos

---

## TRATAMIENTO 2: GESTIÓN DE PERSONAL

### 2.1 Identificación del Tratamiento

**Nombre del tratamiento:** Gestión de Recursos Humanos

**Responsable:** Ana María Ramos Minaya (Anushka Hogar)

### 2.2 Finalidades del Tratamiento

1. **Gestión laboral:**
   - Contratación de empleadas
   - Gestión de nóminas
   - Asignación de trabajos y turnos
   - Registro de horas trabajadas
   - Evaluaciones de desempeño

2. **Obligaciones legales:**
   - Cumplimiento Seguridad Social
   - Cumplimiento Agencia Tributaria
   - Prevención de riesgos laborales

### 2.3 Categorías de Interesados

- Empleadas (trabajadoras por cuenta ajena)
- Colaboradoras externas

### 2.4 Categorías de Datos Personales

**Datos identificativos:**
- Nombre y apellidos
- DNI

**Datos de contacto:**
- Teléfono
- Email

**Datos laborales:**
- Fecha de contratación
- Salario por hora
- Especialidades (confección, instalación, etc.)
- Horas trabajadas
- Evaluaciones de desempeño
- Notas profesionales

**NO tratamos datos sensibles de empleadas** (salud, afiliación sindical, etc.)

### 2.5 Base Legal del Tratamiento

1. **Relación laboral (Art. 6.1.b RGPD):**
   - Ejecución del contrato de trabajo

2. **Obligación legal (Art. 6.1.c RGPD):**
   - Seguridad Social
   - Agencia Tributaria
   - Inspección de Trabajo

### 2.6 Destinatarios de los Datos

- Tesorería General de la Seguridad Social
- Agencia Tributaria
- Entidades bancarias (pago de nóminas)
- Mutua de prevención de riesgos laborales

### 2.7 Transferencias Internacionales

**NO se realizan transferencias internacionales.**

### 2.8 Plazo de Conservación

- **Durante relación laboral:** Todos los datos
- **Tras finalización:** 4 años (obligación legal laboral)
- **Después de 4 años:** Eliminación o anonimización

### 2.9 Medidas de Seguridad

**Mismas medidas técnicas y organizativas que Tratamiento 1:**
- Cifrado AES-256-GCM
- Control de acceso JWT + roles
- Auditoría completa
- Backups automáticos diarios

---

## REGISTRO DE CAMBIOS

| Fecha | Versión | Cambios |
|-------|---------|---------|
| 18/01/2026 | 1.0 | Versión inicial del Registro de Actividades |

---

## DECLARACIÓN DE CONFORMIDAD

**Declaro que:**

1. Este Registro de Actividades de Tratamiento cumple con el artículo 30 del RGPD
2. Los tratamientos descritos se ajustan a las bases legales establecidas
3. Se han implementado las medidas de seguridad técnicas y organizativas apropiadas
4. Se mantiene disponible para la Agencia Española de Protección de Datos (AEPD)

**Responsable del Tratamiento:**

Ana María Ramos Minaya  
Anushka Hogar  
DNI: 32771812D  
Av de Monelos nº109, 15009 A Coruña  
Email: anuskkahogar@gmail.com  
Teléfono: 666 308 290

**Fecha:** 18 de enero de 2026

---

## ANEXOS

**Documentos relacionados:**
- Política de Privacidad (publicada en web)
- Aviso Legal (publicado en web)
- DPA Cloudflare (Data Processing Addendum)
- Procedimiento de gestión de solicitudes RGPD
- Procedimiento de notificación de brechas de seguridad

---

**FIN DEL REGISTRO DE ACTIVIDADES DE TRATAMIENTO**

**Última revisión:** 18 enero 2026  
**Próxima revisión:** 18 enero 2027  
**Responsable:** Ana María Ramos Minaya
